<?php
/* XF1550-PATCH: new upgrade steps for the 1.5.50 community release. XenForo 1.5.50 community release; see /CHANGELOG-1.5.50.md */

class XenForo_Install_Upgrade_1055070 extends XenForo_Install_Upgrade_Abstract
{
	public function getVersionName()
	{
		return '1.5.50';
	}

	/**
	 * Clear the credentials for the social login providers that no longer exist.
	 *
	 * Facebook Graph v2.10 was removed by Meta and Google shut down gapi.auth2 in 2023,
	 * so both login flows fail before they reach the provider. The templates render their
	 * buttons only when these options are non-empty, so blanking the values retires the
	 * feature without touching a single template - which is what keeps add-on template
	 * modifications and custom styles intact.
	 *
	 * The option definitions are deliberately left in place so that {$xenOptions.facebookAppId}
	 * and any add-on reading these options continue to resolve.
	 *
	 * Note: the Facebook Like button is unaffected. It force-initialises the SDK through the
	 * $facebookSdk template container var, independently of the app ID.
	 */
	public function step1()
	{
		$this->executeUpgradeQuery("
			UPDATE xf_option
			SET option_value = ''
			WHERE option_id IN ('facebookAppId', 'facebookAppSecret', 'googleClientId', 'googleClientSecret')
		");
	}

	/**
	 * Move boards off the retired Microsoft Ajax CDN.
	 *
	 * ajax.microsoft.com was decommissioned in 2022; a board still pointed at it serves no
	 * jQuery at all and is effectively dead in the browser. Fall back to the local copy.
	 */
	public function step2()
	{
		$this->executeUpgradeQuery("
			UPDATE xf_option
			SET option_value = 'local'
			WHERE option_id = 'jQuerySource'
				AND option_value = 'microsoft'
		");
	}

	/**
	 * The 'min' setting for uncompressedJs points at js/xenforo/min/, a directory that has
	 * never existed in any XenForo distribution, so selecting it 404s every script on the
	 * board. Send those installs back to the shipped minified files.
	 */
	public function step3()
	{
		$this->executeUpgradeQuery("
			UPDATE xf_option
			SET option_value = '0'
			WHERE option_id = 'uncompressedJs'
				AND option_value = '2'
		");
	}
}
